class Elephant < Animal
  paper_trail_off
end
