class Dog < Animal
end
