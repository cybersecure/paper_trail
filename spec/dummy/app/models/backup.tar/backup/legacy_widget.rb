class LegacyWidget
  include DataMapper::Resource

  property :id,             Serial
  property :name,           String
  property :version,        Integer

  has_paper_trail :ignore  => :version,
                  :version => 'custom_version'
end
