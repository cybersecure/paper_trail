class Cat < Animal
end
