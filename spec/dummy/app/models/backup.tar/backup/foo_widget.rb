class FooWidget < Widget
end
