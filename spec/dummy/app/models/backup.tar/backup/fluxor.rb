class Fluxor < ActiveRecord::Base
  belongs_to :widget
end
